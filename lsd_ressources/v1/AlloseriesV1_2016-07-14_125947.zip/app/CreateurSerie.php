<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CreateurSerie extends Model {

	protected $table = 'createur_serie';
	public $timestamps = false;

}