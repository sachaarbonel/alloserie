<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ProductionSerie extends Model {

	protected $table = 'production_serie';
	public $timestamps = false;

}